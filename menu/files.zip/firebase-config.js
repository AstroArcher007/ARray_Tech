/* ==========================================================================
   Firebase Configuration
   ==========================================================================

   HOW TO SET THIS UP:

   1. Go to https://console.firebase.google.com and create a project
      (or use an existing one).

   2. In the project, click "Add app" -> Web (</> icon) and register an app.
      Firebase will show you a `firebaseConfig` object — copy the values
      into the object below.

   3. Enable Firestore:
      Console -> Build -> Firestore Database -> Create database
      (start in "test mode" while developing, then lock it down with the
      security rules shown at the bottom of this file before going live).

   4. That's it — index.html and admin.html both load this file before
      app.js / admin.js, so `db` is ready to use in both.

   ========================================================================== */

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
};

// Initialize Firebase (compat SDK — works with plain <script> tags, no bundler needed)
firebase.initializeApp(firebaseConfig);

// Shared Firestore handle used by both app.js and admin.js
const db = firebase.firestore();

/* --------------------------------------------------------------------------
   RECOMMENDED FIRESTORE SECURITY RULES
   Paste into Console -> Firestore Database -> Rules. This allows anyone to
   READ the menu (needed for the public client view) but only signed-in
   staff to WRITE. For a simple internal tool without login, you can instead
   restrict writes by other means (e.g. only deploying admin.html privately),
   but rules are the safer approach for production.
   --------------------------------------------------------------------------

   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /menu/{dishId} {
         allow read: if true;
         allow write: if request.auth != null; // requires Firebase Auth sign-in
       }
     }
   }

   -------------------------------------------------------------------------- */
